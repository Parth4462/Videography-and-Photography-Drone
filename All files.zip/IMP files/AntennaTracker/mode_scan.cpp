#include "mode.h"

void ModeScan::update()
{
    update_scan();
}
